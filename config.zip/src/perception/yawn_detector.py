# src/perception/fatigue_detectors.py

from __future__ import annotations
import numpy as np
from scipy.spatial import distance as dist
from types import SimpleNamespace
from collections import deque
import time

from src.perception.base_detector import BaseDetector
from src.perception.types import Face
from src.core.logger import get_logger

log = get_logger(__name__)

MOUTH_IDX = list(range(48, 68))


def mouth_aspect_ratio(mouth_points: np.ndarray) -> float:
    """
    Calcula a MAR (Mouth Aspect Ratio) para detecção de bocejos.
    Quanto maior o valor, mais aberta a boca.
    
    Args:
        mouth_points: Array com os pontos da boca
        
    Returns:
        float: MAR (0 = boca fechada, >0.6 = boca aberta/bocejo)
    """
    a = dist.euclidean(mouth_points[13], mouth_points[19])
    b = dist.euclidean(mouth_points[14], mouth_points[18])
    c = dist.euclidean(mouth_points[15], mouth_points[17])
    d = dist.euclidean(mouth_points[12], mouth_points[16])
    
    if d == 0:
        return 0
    
    return (a + b + c) / (3.0 * d)





# ============================================================================
# DETECTOR DE BOCEJO
# ============================================================================

class YawnDetector(BaseDetector):
    """
    Detector de bocejos usando MAR (Mouth Aspect Ratio).
    Detecta quando a pessoa abre a boca (bocejo/fala).
    """
    
    def __init__(self, cfg: SimpleNamespace):
        self.mar_threshold = cfg.get("mar_threshold", 0.6)
        self.consec_frames = cfg.get("consec_frames_yawn", 3)
        self._counters: dict[int, int] = {}

    def detect(self, frame, faces: list[Face]) -> list[Face]:
        for i, face in enumerate(faces):
            if face.landmarks is None:
                continue

            mouth = face.landmarks[MOUTH_IDX]
            mar = mouth_aspect_ratio(mouth)
            face.extra["mar"] = round(float(mar), 3)

            counter = self._counters.get(i, 0)
            if mar > self.mar_threshold:
                counter += 1
            else:
                if counter >= self.consec_frames:
                    face.extra["yawn"] = True
                    log.info(f"Bocejo detectado - Face {i}")
                else:
                    face.extra["yawn"] = False
                counter = 0
            self._counters[i] = counter
            face.extra.setdefault("yawn", False)

        return faces


