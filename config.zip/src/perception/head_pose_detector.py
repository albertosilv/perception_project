from __future__ import annotations
import cv2
import numpy as np
from types import SimpleNamespace

from src.perception.base_detector import BaseDetector
from src.perception.types import Face
from src.core.logger import get_logger

log = get_logger(__name__)

MODEL_POINTS_3D = np.array([
    (0.0, 0.0, 0.0),          
    (0.0, -330.0, -65.0),     
    (-225.0, 170.0, -135.0),  
    (225.0, 170.0, -135.0),   
    (-150.0, -150.0, -125.0),
    (150.0, -150.0, -125.0),  
], dtype=np.float64)

LANDMARK_IDX = [30, 8, 36, 45, 48, 54]

# Estima a orientação da cabeça (pitch, yaw e roll) usando os landmarks faciais
# e o algoritmo solvePnP, armazenando os ângulos calculados em face.extra["head_pose"].

class HeadPoseDetector(BaseDetector):
    def __init__(self, cfg: SimpleNamespace):
        self.draw_axis = getattr(cfg, "draw_axis", True)

    def detect(self, frame, faces: list[Face]) -> list[Face]:
        h, w = frame.shape[:2]
        focal_length = w
        center = (w / 2, h / 2)
        camera_matrix = np.array([
            [focal_length, 0, center[0]],
            [0, focal_length, center[1]],
            [0, 0, 1],
        ], dtype=np.float64)
        dist_coeffs = np.zeros((4, 1)) 

        for face in faces:
            if face.landmarks is None:
                continue

            image_points = face.landmarks[LANDMARK_IDX].astype(np.float64)

            success, rotation_vec, translation_vec = cv2.solvePnP(
                MODEL_POINTS_3D, image_points, camera_matrix, dist_coeffs,
                flags=cv2.SOLVEPNP_ITERATIVE,
            )
            if not success:
                continue

            rotation_mat, _ = cv2.Rodrigues(rotation_vec)
            pose_mat = cv2.hconcat((rotation_mat, translation_vec))
            _, _, _, _, _, _, euler_angles = cv2.decomposeProjectionMatrix(pose_mat)
            pitch, yaw, roll = [float(a) for a in euler_angles.flatten()]

            face.extra["head_pose"] = {
                "pitch": round(pitch, 1),
                "yaw": round(yaw, 1),
                "roll": round(roll, 1),
            }
            face.extra["_pnp"] = (rotation_vec, translation_vec, camera_matrix, dist_coeffs)

        return faces
